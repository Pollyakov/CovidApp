1. getData() - to get data from two API's, create object with all of the data----done
2. render() - building a table throw a loop running on fetched data.---done
3. css for a table-----done
4. add delete and update buttons ----done
5. add delete functionality----done
6. update dunctionality: Once you click on
the button the data (without the id cell) will turn into a
input field and then the button edit and delete will change
to cancel and confirm.
cancel - cancel the changes and the raw is just raw again
update- change the data and the raw returns to be raw and not input

7. Local storage

8. search field and search functionality
