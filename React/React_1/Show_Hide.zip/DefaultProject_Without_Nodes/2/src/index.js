import React from "react";
import ReactDOM from "react-dom";
import "./index.css";

class ShowHide extends React.Component {
  state = { hidden: "block" };
  toggleView = () => {
    this.setState((prevState) => {
      if (prevState.hidden === "block") return {hidden: "none"}
      else return {hidden: "block"}}
    );
  }
  render() {
    let style = {display: this.state.hidden};
    return (
      <div>
        <div className = "container">
        <button onClick={this.toggleView}>Show/Hide</button>
        <div className = "box" style = {style}></div>
        </div>
      </div>
    );
  };
}

ReactDOM.render(<ShowHide/>, document.getElementById("root"));
