import './card.css';

const Card = (props) => {
    return (
        <div className = 'container'>
            <img src={props.src}></img>
            <p>{props.text}</p>
            <a href = {props.href}>for more information</a>
        </div>
    )
}


export default Card;