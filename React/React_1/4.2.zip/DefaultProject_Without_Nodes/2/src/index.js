import React from 'react';
import ReactDOM from 'react-dom';
import Card from './Card';

function App() {
    if (module.hot) {
        module.hot.accept();
      }

    return (
      <div >
        <Card src = 'https://images.unsplash.com/photo-1452570053594-1b985d6ea890?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=634&q=80'
              text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
            href = "https://www.lipsum.com/" />
        <Card src = 'https://images.unsplash.com/photo-1612712577499-fa3da7fa0a50?ixid=MXwxMjA3fDB8MHxzZWFyY2h8NXx8c2hvcnQlMjBzcmN8ZW58MHx8MHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=60'
            text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
            href = "https://www.lipsum.com/" />
      </div>



    );
  }

ReactDOM.render(<App />, document.getElementById('root')
);
