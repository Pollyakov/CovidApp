import React from "react";
import ReactDOM from "react-dom";
import "./index.css";

class IncrDecr extends React.Component {
  state = { counter: 0, color: "black" };
  increment = () => {
    this.setState((prevState) => {
      if (prevState.counter === 10) return { counter: prevState.counter };
      return { counter: prevState.counter + 1 };
    });
  };
  decrement = () => {
    this.setState((prevState) => {
      if (prevState.counter === -10) return { counter: prevState.counter };
      return { counter: prevState.counter - 1 };
    });
  };
  render() {
    const setColor = () => {
      if (this.state.counter > 0) {
        return "green";
      } else if (this.state.counter < 0) {
        return "red";
      } else {
        return "black";
      }
    };

    let style = { backgoundColor: setColor() };
    return (
      <div>
        <button onClick={this.increment}>increment</button>
        <div className="label" style={style}>
          {this.state.counter}
        </div>
        <button onClick={this.decrement}>decrement</button>
      </div>
    );
  }
}

ReactDOM.render(<IncrDecr />, document.getElementById("root"));
