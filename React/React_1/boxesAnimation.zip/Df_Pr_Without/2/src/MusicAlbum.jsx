import React from 'react';
import 'semantic-ui-css/semantic.min.css'

const MusicAlbum = (props) => {

    return (
       <div>
         <div>the Author is {props.artist}</div>
         <div>the Length is {props.length1}</div>
       </div>
    )
}
MusicAlbum.defaultProps = {
  artist: 'Pollyakov',
  length1: '10'
}
export default MusicAlbum;