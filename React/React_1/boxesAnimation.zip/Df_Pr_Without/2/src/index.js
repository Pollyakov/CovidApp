import React from "react";
import ReactDOM from 'react-dom';
import MusicAlbum from './MusicAlbum.jsx';
import 'semantic-ui-css/semantic.min.css'

const App = (props) => {
 
    return (
    <div >
      <MusicAlbum artist = 'u2' length1 = '8' />
      <MusicAlbum artist = 'Beatlth' length1 = '12' />
      <MusicAlbum artist = 'Igal Bashan'  />
      <MusicAlbum/>
     </div>);
 }

ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

