import { ReactComponent } from '*.svg';
import './card.css';

class Card extends React.Component {
    render() {
        return (
            <div className = 'container'>
            <img ></img>
            <p>{props.text}</p>
            <a href = {props.href}>for more information</a>
        </div>
        )
    }

}


export default Card;