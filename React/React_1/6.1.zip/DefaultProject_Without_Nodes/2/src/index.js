import React from 'react';
import ReactDOM from 'react-dom';
import Card from './Card';

class App extends React.Component {
    render () {
    // if (module.hot) {
    //     module.hot.accept();
    //   }
    return (
      <div >
        <Card src = '../public/backgpng'
              text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
            href = "https://www.lipsum.com/" />
        <Card src = ''
            text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
            href = "https://www.lipsum.com/" />
      </div>

    );
  }
}

ReactDOM.render(<App />, document.getElementById('root')
);
