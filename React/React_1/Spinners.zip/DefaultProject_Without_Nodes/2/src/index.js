import React from "react";
import ReactDOM from 'react-dom';
import Spinner from './Spinner';
import 'semantic-ui-css/semantic.min.css'

class App extends React.Component {
  state = { timeOver: false };

  componentDidMount() {
    setTimeout(()=>{
      this.setState({timeOver: true});
    },3000);
  };
  show = ()=> {
    if (this.state.timeOver) {
      return <div>Time is Over</div>
    } else {
      return <Spinner/>;
    }

  }
  render() {
    return <div className= 'container'>
     {this.show()}
     </div>
 }
}
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root')
);

