import React from "react";
import ReactDOM from "react-dom";

class Counter extends React.Component {
  state = { count: 0 };
  increment = () => this.setState(({ count }) => ({ count: count + 1 }));
  render() {
    return (
      <div>
        <button onClick={this.increment}>increment</button>
        <label>{this.state.count}</label>
      </div>
    );
  }
}
function App() {
  return <Counter />;
}
ReactDOM.render(<App />, document.getElementById("root"));
