
import "./App.css";

function App() {
  const data = ["hello", "world"];
  const number1 = 5;
  const number2 = 6;
  const string = 'I love React';
  return (
    <div>
      <h1>{data.join(" ")}</h1>
      <h1>{`${number1} + ${number2} = ${number1+number2}`}</h1>
      <h1>The string length is {string.length}.</h1>
    </div>
  );
}

export default App;
